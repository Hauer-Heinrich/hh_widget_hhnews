<?php
return [
    'dashboardPreset-hhnews' => [
        'title' => 'Hauer-Heinrich Dashboard',
        'description' => '',
        'iconIdentifier' => 'content-dashboard',
        'defaultWidgets' => [
            'hhnews',
            't3news'
        ],
        'showInWizard' => true
    ],
];
